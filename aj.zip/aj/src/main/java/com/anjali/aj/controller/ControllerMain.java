package com.anjali.aj.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ControllerMain {
	
	@RequestMapping("/")
	public String index(){
		System.out.println("hey this is m home page ");
		return "index";
		
	}
	
	@RequestMapping("contact")
	public String contact() {
		System.out.println("this is contact page :");
		return "contact";
	}

}
