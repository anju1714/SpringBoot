package com.anjali.aj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AjApplicationTests {

	@Test
	void contextLoads() {
	}

}
